import { db } from "@/db";
import { galleryImages } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const rows = await db.select().from(galleryImages).where(eq(galleryImages.isActive, true)).orderBy(asc(galleryImages.displayOrder), asc(galleryImages.createdAt));
    return NextResponse.json({ images: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load gallery", error);
    return NextResponse.json({ images: [] });
  }
}
