import { db } from "@/db";
import { posts } from "@/db/schema";
import { and, asc, desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    if (searchParams.get("featured") === "1") {
      const limit = Math.max(1, Math.min(6, Number(searchParams.get("limit")) || 3));
      const rows = await db.select().from(posts)
        .where(and(eq(posts.status, "PUBLISHED"), eq(posts.featuredHome, true)))
        .orderBy(asc(posts.homeOrder), desc(posts.createdAt))
        .limit(limit);
      // If no posts are explicitly featured yet, fall back to the latest
      // published stories so the homepage is never empty by default.
      if (rows.length > 0) return NextResponse.json({ posts: rows }, { headers: { "Cache-Control": "no-store" } });
      const fallback = await db.select().from(posts).where(eq(posts.status, "PUBLISHED")).orderBy(desc(posts.createdAt)).limit(limit);
      return NextResponse.json({ posts: fallback }, { headers: { "Cache-Control": "no-store" } });
    }
    const rows = await db.select().from(posts).where(eq(posts.status, "PUBLISHED")).orderBy(desc(posts.createdAt));
    return NextResponse.json({ posts: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load news", error);
    return NextResponse.json({ posts: [] });
  }
}
