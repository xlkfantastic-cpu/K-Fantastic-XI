import { db } from "@/db";
import { auditLogs, clubSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { defaultHomepageSettings, mergeHomepageSettings, type HomepageSectionKey, type HomepageSettings } from "@/lib/homepage-settings";

const SECTION_KEYS: HomepageSectionKey[] = ["hero", "fixtures", "intro", "news", "family", "cta"];

function text(value: unknown, fallback: string, max: number) {
  return typeof value === "string" && value.trim() ? value.trim().slice(0, max) : fallback;
}
function textAllowEmpty(value: unknown, fallback: string, max: number) {
  return typeof value === "string" ? value.slice(0, max) : fallback;
}
function validImage(value: string) {
  if (!value) return true;
  return (value.startsWith("https://") || /^data:image\/(png|jpeg|jpg|webp);base64,/i.test(value)) && value.length <= 2_100_000;
}
function link(value: unknown, fallback: string) {
  const v = typeof value === "string" ? value.trim() : "";
  return v ? v.slice(0, 240) : fallback;
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const [row] = await db.select({ value: clubSettings.value }).from(clubSettings).where(eq(clubSettings.key, "homepage")).limit(1);
    return NextResponse.json({ settings: mergeHomepageSettings(row?.value) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load homepage settings for admin", error);
    return NextResponse.json({ message: "Unable to load homepage settings." }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Partial<HomepageSettings>;
    const d = defaultHomepageSettings;

    const sections = { ...d.sections } as HomepageSettings["sections"];
    for (const key of SECTION_KEYS) {
      const incoming = body.sections?.[key];
      sections[key] = {
        enabled: incoming ? incoming.enabled !== false : d.sections[key].enabled,
        order: incoming && Number.isFinite(Number(incoming.order)) ? Math.max(1, Math.min(50, Math.round(Number(incoming.order)))) : d.sections[key].order,
      };
    }

    const introMain = text(body.intro?.mainImage, d.intro.mainImage, 2_100_000);
    const introSmall = text(body.intro?.smallImage, d.intro.smallImage, 2_100_000);
    const familyBg = text(body.family?.backgroundImage, d.family.backgroundImage, 2_100_000);
    if (!validImage(introMain) || !validImage(introSmall) || !validImage(familyBg)) {
      return NextResponse.json({ message: "Images must be a PNG/JPG/WebP upload under ~1.5 MB, or an https:// URL." }, { status: 400 });
    }

    const settings: HomepageSettings = {
      sections,
      intro: {
        eyebrowEn: text(body.intro?.eyebrowEn, d.intro.eyebrowEn, 160),
        eyebrowBn: text(body.intro?.eyebrowBn, d.intro.eyebrowBn, 160),
        headingLine1En: text(body.intro?.headingLine1En, d.intro.headingLine1En, 160),
        headingLine1Bn: text(body.intro?.headingLine1Bn, d.intro.headingLine1Bn, 160),
        headingLine2En: text(body.intro?.headingLine2En, d.intro.headingLine2En, 160),
        headingLine2Bn: text(body.intro?.headingLine2Bn, d.intro.headingLine2Bn, 160),
        descriptionEn: text(body.intro?.descriptionEn, d.intro.descriptionEn, 800),
        descriptionBn: text(body.intro?.descriptionBn, d.intro.descriptionBn, 800),
        journeyNumber: text(body.intro?.journeyNumber, d.intro.journeyNumber, 10),
        journeyLabelEn: textAllowEmpty(body.intro?.journeyLabelEn, d.intro.journeyLabelEn, 80),
        journeyLabelBn: textAllowEmpty(body.intro?.journeyLabelBn, d.intro.journeyLabelBn, 80),
        mainImage: introMain,
        smallImage: introSmall,
        buttonTextEn: text(body.intro?.buttonTextEn, d.intro.buttonTextEn, 80),
        buttonTextBn: text(body.intro?.buttonTextBn, d.intro.buttonTextBn, 80),
        buttonUrl: link(body.intro?.buttonUrl, d.intro.buttonUrl),
      },
      family: {
        eyebrowEn: text(body.family?.eyebrowEn, d.family.eyebrowEn, 160),
        eyebrowBn: text(body.family?.eyebrowBn, d.family.eyebrowBn, 160),
        headingLine1En: text(body.family?.headingLine1En, d.family.headingLine1En, 160),
        headingLine1Bn: text(body.family?.headingLine1Bn, d.family.headingLine1Bn, 160),
        headingLine2En: text(body.family?.headingLine2En, d.family.headingLine2En, 160),
        headingLine2Bn: text(body.family?.headingLine2Bn, d.family.headingLine2Bn, 160),
        descriptionEn: text(body.family?.descriptionEn, d.family.descriptionEn, 800),
        descriptionBn: text(body.family?.descriptionBn, d.family.descriptionBn, 800),
        buttonTextEn: text(body.family?.buttonTextEn, d.family.buttonTextEn, 80),
        buttonTextBn: text(body.family?.buttonTextBn, d.family.buttonTextBn, 80),
        buttonUrl: link(body.family?.buttonUrl, d.family.buttonUrl),
        backgroundImage: familyBg,
      },
      cta: {
        eyebrowEn: text(body.cta?.eyebrowEn, d.cta.eyebrowEn, 160),
        eyebrowBn: text(body.cta?.eyebrowBn, d.cta.eyebrowBn, 160),
        headingEn: text(body.cta?.headingEn, d.cta.headingEn, 160),
        headingBn: text(body.cta?.headingBn, d.cta.headingBn, 160),
        descriptionEn: text(body.cta?.descriptionEn, d.cta.descriptionEn, 400),
        descriptionBn: text(body.cta?.descriptionBn, d.cta.descriptionBn, 400),
        buttonTextEn: text(body.cta?.buttonTextEn, d.cta.buttonTextEn, 80),
        buttonTextBn: text(body.cta?.buttonTextBn, d.cta.buttonTextBn, 80),
        buttonUrl: link(body.cta?.buttonUrl, d.cta.buttonUrl),
      },
      fixturesCount: Number.isFinite(Number(body.fixturesCount)) ? Math.max(1, Math.min(5, Math.round(Number(body.fixturesCount)))) : d.fixturesCount,
      newsCount: Number.isFinite(Number(body.newsCount)) ? Math.max(1, Math.min(6, Math.round(Number(body.newsCount)))) : d.newsCount,
    };

    await db.insert(clubSettings).values({ key: "homepage", value: settings }).onConflictDoUpdate({
      target: clubSettings.key,
      set: { value: settings, updatedAt: new Date() },
    });
    await db.insert(auditLogs).values({
      actor: session.email,
      action: "Homepage content updated",
      entityType: "CLUB_SETTINGS",
      entityId: "homepage",
      details: { sections: Object.fromEntries(SECTION_KEYS.map(k => [k, settings.sections[k].enabled])) },
    });

    return NextResponse.json({ message: "Homepage updated successfully.", settings });
  } catch (error) {
    console.error("Unable to save homepage settings", error);
    return NextResponse.json({ message: "Unable to save homepage settings." }, { status: 500 });
  }
}
