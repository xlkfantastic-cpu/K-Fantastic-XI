import { db } from "@/db";
import { auditLogs, feeStructures } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const CATEGORIES = ["MEMBERSHIP", "TOURNAMENT", "JERSEY", "ADMISSION", "CUSTOM"];
const FREQUENCIES = ["MONTHLY", "ONE_TIME", "PER_EVENT"];
const AUDIENCES = ["ALL", "PLAYERS", "NEW_MEMBERS"];

// Default club fees, used only to seed the table the very first time it's empty — after that,
// every fee lives in the database and this array is never read again.
const SEED_DEFAULTS = [
  { name: "Monthly membership fee", nameBn: "মাসিক সদস্য ফি", description: "Charged to every active member each month.", amount: "500", category: "MEMBERSHIP" as const, frequency: "MONTHLY" as const, audience: "ALL" as const, active: true },
  { name: "Tournament participation fee", nameBn: "টুর্নামেন্ট অংশগ্রহণ ফি", description: "Applies when a player registers for a tournament.", amount: "1000", category: "TOURNAMENT" as const, frequency: "PER_EVENT" as const, audience: "PLAYERS" as const, active: true },
  { name: "Jersey payment", nameBn: "জার্সি পেমেন্ট", description: "One-time cost for a printed matchday jersey.", amount: "850", category: "JERSEY" as const, frequency: "ONE_TIME" as const, audience: "PLAYERS" as const, active: true },
  { name: "New member admission fee", nameBn: "নতুন সদস্য ভর্তি ফি", description: "Optional onboarding fee for first-time members.", amount: "300", category: "ADMISSION" as const, frequency: "ONE_TIME" as const, audience: "NEW_MEMBERS" as const, active: false },
];

async function ensureSeeded() {
  const existing = await db.select({ id: feeStructures.id }).from(feeStructures).limit(1);
  if (existing.length === 0) await db.insert(feeStructures).values(SEED_DEFAULTS);
}

function clean(value: unknown, max: number) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    await ensureSeeded();
    const rows = await db.select().from(feeStructures).orderBy(asc(feeStructures.createdAt));
    return NextResponse.json({ fees: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load fee structures", error);
    return NextResponse.json({ fees: [] });
  }
}

export async function POST(request: Request) {
  const admin = requireAdminSession(request);
  if (!admin) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const name = clean(body.name, 120);
    const nameBn = clean(body.nameBn, 120) || name;
    const description = clean(body.description, 500);
    const amount = Number(body.amount);
    const category = CATEGORIES.includes(String(body.category)) ? String(body.category) : "CUSTOM";
    const frequency = FREQUENCIES.includes(String(body.frequency)) ? String(body.frequency) : "ONE_TIME";
    const audience = AUDIENCES.includes(String(body.audience)) ? String(body.audience) : "ALL";
    const active = body.active !== false;

    if (!name || !Number.isFinite(amount) || amount < 0) {
      return NextResponse.json({ message: "Enter a fee name and a valid amount." }, { status: 400 });
    }

    const [created] = await db.insert(feeStructures).values({
      name, nameBn, description: description || null, amount: amount.toFixed(2),
      category: category as typeof feeStructures.$inferInsert.category,
      frequency: frequency as typeof feeStructures.$inferInsert.frequency,
      audience: audience as typeof feeStructures.$inferInsert.audience,
      active,
    }).returning();

    await db.insert(auditLogs).values({ actor: admin.email, action: "Fee created", entityType: "FEE_STRUCTURE", entityId: created.id, details: { name, amount } });
    return NextResponse.json({ message: "Fee created.", fee: created }, { status: 201 });
  } catch (error) {
    console.error("Unable to create fee", error);
    return NextResponse.json({ message: "Unable to create fee." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  const admin = requireAdminSession(request);
  if (!admin) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = typeof body.id === "string" ? body.id : "";
    if (!id) return NextResponse.json({ message: "Invalid fee id." }, { status: 400 });

    const patch: Partial<typeof feeStructures.$inferInsert> = { updatedAt: new Date() };
    if (body.name !== undefined) {
      const name = clean(body.name, 120);
      if (!name) return NextResponse.json({ message: "Fee name cannot be empty." }, { status: 400 });
      patch.name = name;
    }
    if (body.nameBn !== undefined) patch.nameBn = clean(body.nameBn, 120) || (patch.name as string | undefined);
    if (body.description !== undefined) patch.description = clean(body.description, 500) || null;
    if (body.amount !== undefined) {
      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount < 0) return NextResponse.json({ message: "Enter a valid amount." }, { status: 400 });
      patch.amount = amount.toFixed(2);
    }
    if (body.category !== undefined && CATEGORIES.includes(String(body.category))) patch.category = body.category as typeof feeStructures.$inferInsert.category;
    if (body.frequency !== undefined && FREQUENCIES.includes(String(body.frequency))) patch.frequency = body.frequency as typeof feeStructures.$inferInsert.frequency;
    if (body.audience !== undefined && AUDIENCES.includes(String(body.audience))) patch.audience = body.audience as typeof feeStructures.$inferInsert.audience;
    if (body.active !== undefined) patch.active = Boolean(body.active);

    const [updated] = await db.update(feeStructures).set(patch).where(eq(feeStructures.id, id)).returning();
    if (!updated) return NextResponse.json({ message: "Fee not found." }, { status: 404 });

    await db.insert(auditLogs).values({ actor: admin.email, action: "Fee updated", entityType: "FEE_STRUCTURE", entityId: id, details: patch });
    return NextResponse.json({ message: "Fee updated.", fee: updated });
  } catch (error) {
    console.error("Unable to update fee", error);
    return NextResponse.json({ message: "Unable to update fee." }, { status: 500 });
  }
}

// Existing payments keep their own feeType/amount snapshot regardless of this delete
// (payments.feeStructureId is ON DELETE SET NULL), so removing a fee never rewrites history.
export async function DELETE(request: Request) {
  const admin = requireAdminSession(request);
  if (!admin) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing fee id." }, { status: 400 });
    await db.delete(feeStructures).where(eq(feeStructures.id, id));
    await db.insert(auditLogs).values({ actor: admin.email, action: "Fee deleted", entityType: "FEE_STRUCTURE", entityId: id, details: {} });
    return NextResponse.json({ message: "Fee deleted." });
  } catch (error) {
    console.error("Unable to delete fee", error);
    return NextResponse.json({ message: "Unable to delete fee." }, { status: 500 });
  }
}
