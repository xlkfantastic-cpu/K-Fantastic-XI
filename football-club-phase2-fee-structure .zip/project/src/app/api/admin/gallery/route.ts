import { db } from "@/db";
import { auditLogs, galleryImages } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";
function validImage(image: string) {
  return (image.startsWith("https://") || /^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(image)) && image.length <= 4_200_000;
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select().from(galleryImages).orderBy(asc(galleryImages.displayOrder), asc(galleryImages.createdAt));
    return NextResponse.json({ images: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load gallery for admin", error);
    return NextResponse.json({ images: [] });
  }
}

export async function POST(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const title = clean(body.title, 200);
    const category = clean(body.category, 40) || "MATCHDAY";
    const imageUrl = typeof body.imageUrl === "string" ? body.imageUrl : "";
    if (!title || !imageUrl) return NextResponse.json({ message: "Title and photo are required." }, { status: 400 });
    if (!validImage(imageUrl)) return NextResponse.json({ message: "Photo must be a PNG/JPG/WebP/GIF under 4 MB, or an https:// URL." }, { status: 400 });

    const existing = await db.select({ maxOrder: galleryImages.displayOrder }).from(galleryImages).orderBy(desc(galleryImages.displayOrder)).limit(1);
    const nextOrder = (existing[0]?.maxOrder || 0) + 1;
    const [created] = await db.insert(galleryImages).values({ title, category, imageUrl, displayOrder: nextOrder }).returning({ id: galleryImages.id });
    await db.insert(auditLogs).values({ actor: session.email, action: "Gallery photo added", entityType: "GALLERY_IMAGE", entityId: created.id, details: { title, category } });
    return NextResponse.json({ message: "Photo added." }, { status: 201 });
  } catch (error) {
    console.error("Unable to add gallery photo", error);
    return NextResponse.json({ message: "Unable to save the photo." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = typeof body.id === "string" ? body.id : "";
    if (!id) return NextResponse.json({ message: "Missing photo id." }, { status: 400 });

    const patch: Record<string, unknown> = {};
    if ("title" in body) patch.title = clean(body.title, 200);
    if ("category" in body) patch.category = clean(body.category, 40) || "MATCHDAY";
    if ("isActive" in body) patch.isActive = !!body.isActive;
    if ("imageUrl" in body) {
      const imageUrl = typeof body.imageUrl === "string" ? body.imageUrl : "";
      if (!validImage(imageUrl)) return NextResponse.json({ message: "Photo must be a PNG/JPG/WebP/GIF under 4 MB, or an https:// URL." }, { status: 400 });
      patch.imageUrl = imageUrl;
    }

    const [updated] = await db.update(galleryImages).set(patch).where(eq(galleryImages.id, id)).returning({ id: galleryImages.id });
    if (!updated) return NextResponse.json({ message: "Photo not found." }, { status: 404 });
    await db.insert(auditLogs).values({ actor: session.email, action: "Gallery photo updated", entityType: "GALLERY_IMAGE", entityId: id, details: {} });
    return NextResponse.json({ message: "Photo updated." });
  } catch (error) {
    console.error("Unable to update gallery photo", error);
    return NextResponse.json({ message: "Unable to update the photo." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing photo id." }, { status: 400 });
    await db.delete(galleryImages).where(eq(galleryImages.id, id));
    await db.insert(auditLogs).values({ actor: session.email, action: "Gallery photo deleted", entityType: "GALLERY_IMAGE", entityId: id, details: {} });
    return NextResponse.json({ message: "Photo deleted." });
  } catch (error) {
    console.error("Unable to delete gallery photo", error);
    return NextResponse.json({ message: "Unable to delete the photo." }, { status: 500 });
  }
}
