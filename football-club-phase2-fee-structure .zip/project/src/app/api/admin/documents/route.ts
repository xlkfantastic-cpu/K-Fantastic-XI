import { db } from "@/db";
import { auditLogs, clubDocuments } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";

const clean = (value: unknown, max: number) => typeof value === "string" ? value.trim().slice(0, max) : "";
function validFile(file: string) {
  return /^data:(application\/pdf|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document|application\/msword);base64,/i.test(file) && file.length <= 8_400_000;
}

export async function GET(request: Request) {
  if (!requireAdminSession(request)) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const rows = await db.select().from(clubDocuments).orderBy(asc(clubDocuments.createdAt));
    return NextResponse.json({ documents: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load documents for admin", error);
    return NextResponse.json({ documents: [] });
  }
}

export async function POST(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const title = clean(body.title, 200);
    const category = clean(body.category, 60) || "Official";
    const fileUrl = typeof body.fileUrl === "string" ? body.fileUrl : "";
    const fileName = clean(body.fileName, 200) || title;
    if (!title || !fileUrl) return NextResponse.json({ message: "Title and file are required." }, { status: 400 });
    if (!validFile(fileUrl)) return NextResponse.json({ message: "File must be a PDF or Word document under 8 MB." }, { status: 400 });
    const fileType = fileUrl.startsWith("data:application/pdf") ? "PDF" : "DOCX";

    const [created] = await db.insert(clubDocuments).values({ title, category, fileUrl, fileName, fileType }).returning({ id: clubDocuments.id });
    await db.insert(auditLogs).values({ actor: session.email, action: "Document uploaded", entityType: "DOCUMENT", entityId: created.id, details: { title, category } });
    return NextResponse.json({ message: "Document uploaded." }, { status: 201 });
  } catch (error) {
    console.error("Unable to upload document", error);
    return NextResponse.json({ message: "Unable to save the document." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = typeof body.id === "string" ? body.id : "";
    if (!id) return NextResponse.json({ message: "Missing document id." }, { status: 400 });

    const patch: Record<string, unknown> = {};
    if ("title" in body) patch.title = clean(body.title, 200);
    if ("category" in body) patch.category = clean(body.category, 60) || "Official";
    if ("isActive" in body) patch.isActive = !!body.isActive;
    if ("fileUrl" in body) {
      const fileUrl = typeof body.fileUrl === "string" ? body.fileUrl : "";
      if (!validFile(fileUrl)) return NextResponse.json({ message: "File must be a PDF or Word document under 8 MB." }, { status: 400 });
      patch.fileUrl = fileUrl;
      patch.fileType = fileUrl.startsWith("data:application/pdf") ? "PDF" : "DOCX";
    }

    const [updated] = await db.update(clubDocuments).set(patch).where(eq(clubDocuments.id, id)).returning({ id: clubDocuments.id });
    if (!updated) return NextResponse.json({ message: "Document not found." }, { status: 404 });
    await db.insert(auditLogs).values({ actor: session.email, action: "Document updated", entityType: "DOCUMENT", entityId: id, details: {} });
    return NextResponse.json({ message: "Document updated." });
  } catch (error) {
    console.error("Unable to update document", error);
    return NextResponse.json({ message: "Unable to update the document." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  const session = requireAdminSession(request);
  if (!session) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing document id." }, { status: 400 });
    await db.delete(clubDocuments).where(eq(clubDocuments.id, id));
    await db.insert(auditLogs).values({ actor: session.email, action: "Document deleted", entityType: "DOCUMENT", entityId: id, details: {} });
    return NextResponse.json({ message: "Document deleted." });
  } catch (error) {
    console.error("Unable to delete document", error);
    return NextResponse.json({ message: "Unable to delete the document." }, { status: 500 });
  }
}
