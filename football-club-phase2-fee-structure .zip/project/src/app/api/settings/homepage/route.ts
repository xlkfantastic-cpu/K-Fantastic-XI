import { db } from "@/db";
import { clubSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { mergeHomepageSettings } from "@/lib/homepage-settings";

export async function GET() {
  try {
    const [row] = await db.select({ value: clubSettings.value }).from(clubSettings).where(eq(clubSettings.key, "homepage")).limit(1);
    return NextResponse.json({ settings: mergeHomepageSettings(row?.value) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load homepage settings", error);
    return NextResponse.json({ settings: mergeHomepageSettings(null) }, { headers: { "Cache-Control": "no-store" } });
  }
}
