import { db } from "@/db";
import { matches } from "@/db/schema";
import { and, asc, eq, gte } from "drizzle-orm";
import { NextResponse } from "next/server";

// GET: by default, the next upcoming match (soonest match with status UPCOMING
// and a future/today datetime) — used for the hero "next match" ribbon.
// GET ?list=1&limit=N: the next N upcoming, homepage-visible matches — used
// by the homepage "Upcoming Fixtures" strip, which is now database-backed
// instead of static content.
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const now = new Date();
    now.setHours(0, 0, 0, 0); // include matches later today

    if (searchParams.get("list") === "1") {
      const limit = Math.max(1, Math.min(5, Number(searchParams.get("limit")) || 2));
      const rows = await db.select().from(matches)
        .where(and(eq(matches.status, "UPCOMING"), eq(matches.showOnHomepage, true), gte(matches.matchDatetime, now)))
        .orderBy(asc(matches.matchDatetime))
        .limit(limit);
      return NextResponse.json({ matches: rows }, { headers: { "Cache-Control": "no-store" } });
    }

    const [next] = await db.select().from(matches)
      .where(and(eq(matches.status, "UPCOMING"), gte(matches.matchDatetime, now)))
      .orderBy(asc(matches.matchDatetime))
      .limit(1);
    return NextResponse.json({ match: next || null }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load matches", error);
    return NextResponse.json({ match: null, matches: [] });
  }
}
