import { db } from "@/db";
import { feeStructures } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

// Public/member-facing: only active fees, and only the fields a payer needs — no
// created/updated timestamps or anything admin-internal.
export async function GET() {
  try {
    const rows = await db.select({
      id: feeStructures.id,
      name: feeStructures.name,
      nameBn: feeStructures.nameBn,
      description: feeStructures.description,
      amount: feeStructures.amount,
      category: feeStructures.category,
      frequency: feeStructures.frequency,
      audience: feeStructures.audience,
    }).from(feeStructures).where(eq(feeStructures.active, true)).orderBy(asc(feeStructures.createdAt));

    return NextResponse.json({ fees: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load active fees", error);
    return NextResponse.json({ fees: [] });
  }
}
