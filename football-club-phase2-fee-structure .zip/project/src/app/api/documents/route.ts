import { db } from "@/db";
import { clubDocuments } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { MEMBER_SESSION_COOKIE, verifyMemberSessionToken } from "@/lib/member-session";

export async function GET(request: Request) {
  try {
    const cookieHeader = request.headers.get("cookie") || "";
    const token = cookieHeader.split(";").map(part => part.trim()).find(part => part.startsWith(`${MEMBER_SESSION_COOKIE}=`))?.split("=")[1];
    const session = verifyMemberSessionToken(token);
    if (!session) return NextResponse.json({ message: "Sign in required." }, { status: 401 });

    const rows = await db.select().from(clubDocuments).where(eq(clubDocuments.isActive, true)).orderBy(asc(clubDocuments.createdAt));
    return NextResponse.json({ documents: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Unable to load documents", error);
    return NextResponse.json({ documents: [] });
  }
}
