"use client";

import { useEffect, useState } from "react";
import { ClubMark } from "./ui";
import { useBranding } from "@/lib/branding";

const SPLASH_SESSION_KEY = "ffc-splash-shown";

export function SplashScreen({ children }: { children: React.ReactNode }) {
  const { branding } = useBranding();
  const [phase, setPhase] = useState<"checking" | "showing" | "leaving" | "done">("checking");

  useEffect(() => {
    let alreadyShown = false;
    try { alreadyShown = sessionStorage.getItem(SPLASH_SESSION_KEY) === "1"; } catch { /* storage unavailable */ }
    if (alreadyShown) { setPhase("done"); return; }
    setPhase("showing");
    const leaveTimer = setTimeout(() => setPhase("leaving"), 1100);
    const doneTimer = setTimeout(() => {
      setPhase("done");
      try { sessionStorage.setItem(SPLASH_SESSION_KEY, "1"); } catch { /* storage unavailable */ }
    }, 1550);
    return () => { clearTimeout(leaveTimer); clearTimeout(doneTimer) };
  }, []);

  if (phase === "checking") return null;

  return (
    <>
      {phase !== "done" && (
        <div className={`splash-screen ${phase === "leaving" ? "leaving" : ""}`} role="status" aria-label="Loading">
          <div className="splash-mark"><ClubMark /></div>
          <b>{branding.shortName}</b>
          <span className="splash-bar"><i /></span>
        </div>
      )}
      {children}
    </>
  );
}
