// Shared shape + sensible defaults for the homepage CMS ("Homepage Manager").
// Stored server-side inside club_settings under the key "homepage" (see
// /api/settings/homepage and /api/admin/settings/homepage). Defaults below
// match the original hardcoded homepage copy so a fresh database renders
// identically to the previous design until an admin edits it.

export type HomepageSectionKey = "hero" | "fixtures" | "intro" | "news" | "family" | "cta";

export type HomepageSections = Record<HomepageSectionKey, { enabled: boolean; order: number }>;

export type HomepageIntro = {
  eyebrowEn: string; eyebrowBn: string;
  headingLine1En: string; headingLine1Bn: string;
  headingLine2En: string; headingLine2Bn: string;
  descriptionEn: string; descriptionBn: string;
  journeyNumber: string;
  journeyLabelEn: string; journeyLabelBn: string;
  mainImage: string;
  smallImage: string;
  buttonTextEn: string; buttonTextBn: string;
  buttonUrl: string;
};

export type HomepageFamily = {
  eyebrowEn: string; eyebrowBn: string;
  headingLine1En: string; headingLine1Bn: string;
  headingLine2En: string; headingLine2Bn: string;
  descriptionEn: string; descriptionBn: string;
  buttonTextEn: string; buttonTextBn: string;
  buttonUrl: string;
  backgroundImage: string;
};

export type HomepageCta = {
  eyebrowEn: string; eyebrowBn: string;
  headingEn: string; headingBn: string;
  descriptionEn: string; descriptionBn: string;
  buttonTextEn: string; buttonTextBn: string;
  buttonUrl: string;
};

export type HomepageSettings = {
  sections: HomepageSections;
  intro: HomepageIntro;
  family: HomepageFamily;
  cta: HomepageCta;
  fixturesCount: number;
  newsCount: number;
};

const introImage = "https://images.pexels.com/photos/38089483/pexels-photo-38089483.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600";
const ballImage = "https://images.pexels.com/photos/23848612/pexels-photo-23848612.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600";
const familyImage = "https://images.pexels.com/photos/16651538/pexels-photo-16651538.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600";

export const defaultHomepageSettings: HomepageSettings = {
  sections: {
    hero: { enabled: true, order: 1 },
    fixtures: { enabled: true, order: 2 },
    intro: { enabled: true, order: 3 },
    news: { enabled: true, order: 4 },
    family: { enabled: true, order: 5 },
    cta: { enabled: true, order: 6 },
  },
  intro: {
    eyebrowEn: "THIS IS FANTASTIC FC", eyebrowBn: "এটাই ফ্যান্টাস্টিক এফসি",
    headingLine1En: "ROOTED IN COMMUNITY.", headingLine1Bn: "শিকড়ে আমাদের সমাজ।",
    headingLine2En: "DRIVEN BY THE GAME.", headingLine2Bn: "প্রেরণায় ফুটবল।",
    descriptionEn: "Born in the fields of Kulanandapur, Fantastic FC is where local talent, lifelong friendship and the pursuit of excellence come together.",
    descriptionBn: "কুলানন্দপুরের মাঠে জন্ম নেওয়া ফ্যান্টাস্টিক এফসি—স্থানীয় প্রতিভা, আজীবন বন্ধুত্ব এবং শ্রেষ্ঠত্বের সাধনার মিলনস্থল।",
    journeyNumber: "13",
    journeyLabelEn: "YEARS OF\nTHE JOURNEY", journeyLabelBn: "১৩ বছরের\nপথচলা",
    mainImage: introImage,
    smallImage: ballImage,
    buttonTextEn: "Our club story", buttonTextBn: "ক্লাবের গল্প",
    buttonUrl: "/about",
  },
  family: {
    eyebrowEn: "MORE THAN A TEAM", eyebrowBn: "একটি দলের চেয়েও বেশি",
    headingLine1En: "THE FANTASTIC", headingLine1Bn: "দ্য ফ্যান্টাস্টিক",
    headingLine2En: "FAMILY", headingLine2Bn: "ফ্যামিলি",
    descriptionEn: "Every match, every memory, every milestone—together.",
    descriptionBn: "প্রতিটি ম্যাচ, প্রতিটি স্মৃতি, প্রতিটি অর্জন—একসঙ্গে।",
    buttonTextEn: "Explore our gallery", buttonTextBn: "গ্যালারি দেখুন",
    buttonUrl: "/gallery",
    backgroundImage: familyImage,
  },
  cta: {
    eyebrowEn: "WE ARE ONE CLUB", eyebrowBn: "আমরা এক ক্লাব",
    headingEn: "READY TO BE FANTASTIC?", headingBn: "ফ্যান্টাস্টিক হতে প্রস্তুত?",
    descriptionEn: "Join the family. Wear the badge. Make your mark.",
    descriptionBn: "পরিবারে যোগ দিন। ব্যাজ পরুন। নিজের ছাপ রাখুন।",
    buttonTextEn: "Start your journey", buttonTextBn: "যাত্রা শুরু করুন",
    buttonUrl: "/register",
  },
  fixturesCount: 2,
  newsCount: 3,
};

// Deep-merges partial/stored settings over the defaults so newly added
// fields always have a safe value even if the saved JSON predates them.
export function mergeHomepageSettings(stored: unknown): HomepageSettings {
  const s = (stored && typeof stored === "object" ? stored : {}) as Partial<HomepageSettings>;
  const d = defaultHomepageSettings;
  return {
    sections: { ...d.sections, ...(s.sections || {}) } as HomepageSections,
    intro: { ...d.intro, ...(s.intro || {}) },
    family: { ...d.family, ...(s.family || {}) },
    cta: { ...d.cta, ...(s.cta || {}) },
    fixturesCount: typeof s.fixturesCount === "number" && s.fixturesCount > 0 ? Math.min(5, Math.round(s.fixturesCount)) : d.fixturesCount,
    newsCount: typeof s.newsCount === "number" && s.newsCount > 0 ? Math.min(6, Math.round(s.newsCount)) : d.newsCount,
  };
}
