import { createHmac, timingSafeEqual } from "node:crypto";

export const ADMIN_SESSION_COOKIE = "ffc_admin_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

function secret() {
  const value = process.env.AUTH_SECRET;
  if (!value) {
    // No insecure fallback: every deployment must set its own AUTH_SECRET, or sessions
    // could be forged by anyone who reads this source code.
    throw new Error("AUTH_SECRET environment variable is not set. Set a long random AUTH_SECRET before running the app.");
  }
  return value;
}

function sign(payload: string) {
  return createHmac("sha256", secret()).update(payload).digest("hex");
}

export function createAdminSessionToken(email: string): string {
  const expires = Date.now() + SESSION_TTL_MS;
  const payload = `${email}|${expires}`;
  const signature = sign(payload);
  return Buffer.from(`${payload}|${signature}`).toString("base64url");
}

// Extracts and verifies the admin session directly from a Request's Cookie header.
// Use this at the top of every /api/admin/* route handler so the API itself is
// protected even though the Next.js middleware only guards the /admin page routes.
export function requireAdminSession(request: Request): { email: string } | null {
  const cookieHeader = request.headers.get("cookie") || "";
  const token = cookieHeader
    .split(";")
    .map(part => part.trim())
    .find(part => part.startsWith(`${ADMIN_SESSION_COOKIE}=`))
    ?.split("=")[1];
  return verifyAdminSessionToken(token);
}

export function verifyAdminSessionToken(token: string | undefined | null): { email: string } | null {
  if (!token) return null;
  try {
    const decoded = Buffer.from(token, "base64url").toString("utf8");
    const parts = decoded.split("|");
    if (parts.length !== 3) return null;
    const [email, expiresRaw, signature] = parts;
    const payload = `${email}|${expiresRaw}`;
    const expected = sign(payload);
    const expectedBuffer = Buffer.from(expected);
    const signatureBuffer = Buffer.from(signature);
    if (expectedBuffer.length !== signatureBuffer.length || !timingSafeEqual(expectedBuffer, signatureBuffer)) return null;
    const expires = Number(expiresRaw);
    if (!Number.isFinite(expires) || Date.now() > expires) return null;
    return { email };
  } catch {
    return null;
  }
}
