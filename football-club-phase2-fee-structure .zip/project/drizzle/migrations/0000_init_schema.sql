CREATE TYPE "public"."application_status" AS ENUM('PENDING', 'APPROVED', 'REJECTED');--> statement-breakpoint
CREATE TYPE "public"."fee_audience" AS ENUM('ALL', 'PLAYERS', 'NEW_MEMBERS');--> statement-breakpoint
CREATE TYPE "public"."fee_category" AS ENUM('MEMBERSHIP', 'TOURNAMENT', 'JERSEY', 'ADMISSION', 'CUSTOM');--> statement-breakpoint
CREATE TYPE "public"."fee_frequency" AS ENUM('MONTHLY', 'ONE_TIME', 'PER_EVENT');--> statement-breakpoint
CREATE TYPE "public"."finance_category" AS ENUM('GENERAL', 'EXPENSE', 'PLAYER_PAYMENT');--> statement-breakpoint
CREATE TYPE "public"."jersey_order_status" AS ENUM('PENDING', 'APPROVED', 'PAID', 'PROCESSING', 'READY', 'DELIVERED', 'CANCELLED', 'REJECTED');--> statement-breakpoint
CREATE TYPE "public"."member_status" AS ENUM('PENDING', 'ACTIVE', 'INACTIVE', 'BLACKLISTED', 'REJECTED');--> statement-breakpoint
CREATE TYPE "public"."payment_status" AS ENUM('PENDING', 'PAID', 'REJECTED');--> statement-breakpoint
CREATE TYPE "public"."player_position" AS ENUM('GOALKEEPER', 'DEFENDER', 'MIDFIELDER', 'FORWARD');--> statement-breakpoint
CREATE TYPE "public"."post_status" AS ENUM('DRAFT', 'PUBLISHED');--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"actor" varchar(160) NOT NULL,
	"action" varchar(180) NOT NULL,
	"entity_type" varchar(80) NOT NULL,
	"entity_id" varchar(100),
	"details" jsonb DEFAULT '{}'::jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "banners" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(180) NOT NULL,
	"subtitle" text NOT NULL,
	"eyebrow" varchar(120) DEFAULT 'KULANANDAPUR''S FOOTBALL LEGACY' NOT NULL,
	"image_url" text NOT NULL,
	"image_position" varchar(20) DEFAULT 'center 40%' NOT NULL,
	"mobile_image_url" text,
	"mobile_image_position" varchar(20) DEFAULT '65% center' NOT NULL,
	"button_text" varchar(80) DEFAULT 'Explore match centre' NOT NULL,
	"button_link" varchar(240) DEFAULT '/matches' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"display_order" integer DEFAULT 1 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "club_documents" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(200) NOT NULL,
	"category" varchar(60) DEFAULT 'Official' NOT NULL,
	"file_url" text NOT NULL,
	"file_name" varchar(200) NOT NULL,
	"file_type" varchar(10) DEFAULT 'PDF' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "club_settings" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"key" varchar(100) NOT NULL,
	"value" jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "club_settings_key_unique" UNIQUE("key")
);
--> statement-breakpoint
CREATE TABLE "contact_messages" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(160) NOT NULL,
	"mobile" varchar(30),
	"email" varchar(180) NOT NULL,
	"subject" varchar(200) NOT NULL,
	"message" text NOT NULL,
	"is_read" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "fee_structures" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(120) NOT NULL,
	"name_bn" varchar(120) NOT NULL,
	"description" text,
	"amount" numeric(12, 2) NOT NULL,
	"category" "fee_category" DEFAULT 'CUSTOM' NOT NULL,
	"frequency" "fee_frequency" DEFAULT 'ONE_TIME' NOT NULL,
	"audience" "fee_audience" DEFAULT 'ALL' NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "finance_entries" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(200) NOT NULL,
	"category" "finance_category" DEFAULT 'GENERAL' NOT NULL,
	"income" numeric(12, 2) DEFAULT '0' NOT NULL,
	"expense" numeric(12, 2) DEFAULT '0' NOT NULL,
	"member_id" uuid,
	"method" varchar(60),
	"note" varchar(300),
	"created_by" varchar(180),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "gallery_images" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(200) NOT NULL,
	"category" varchar(40) DEFAULT 'MATCHDAY' NOT NULL,
	"image_url" text NOT NULL,
	"display_order" integer DEFAULT 0 NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "jersey_orders" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"member_id" uuid NOT NULL,
	"size" varchar(10) NOT NULL,
	"jersey_number" integer NOT NULL,
	"print_name" varchar(40) NOT NULL,
	"quantity" integer DEFAULT 1 NOT NULL,
	"unit_price" numeric(10, 2) DEFAULT '850' NOT NULL,
	"status" "jersey_order_status" DEFAULT 'PENDING' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "lineups" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"team_name" varchar(120) NOT NULL,
	"match_title" varchar(180) NOT NULL,
	"formation" varchar(20) DEFAULT '4-3-3' NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"players" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "matches" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"opponent_name" varchar(120) NOT NULL,
	"opponent_logo_url" text,
	"match_datetime" timestamp with time zone NOT NULL,
	"competition" varchar(120),
	"group_name" varchar(60),
	"venue" varchar(160),
	"match_type" varchar(40) DEFAULT 'LEAGUE' NOT NULL,
	"home_away" varchar(10) DEFAULT 'HOME' NOT NULL,
	"status" varchar(20) DEFAULT 'UPCOMING' NOT NULL,
	"home_score" integer,
	"away_score" integer,
	"show_on_homepage" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "members" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"member_id" varchar(24) NOT NULL,
	"full_name" varchar(160) NOT NULL,
	"mobile" varchar(30) NOT NULL,
	"email" varchar(180) NOT NULL,
	"date_of_birth" date,
	"address" text,
	"emergency_contact" varchar(30),
	"jersey_number" integer,
	"position" "player_position",
	"matches_played" integer DEFAULT 0 NOT NULL,
	"goals" integer DEFAULT 0 NOT NULL,
	"assists" integer DEFAULT 0 NOT NULL,
	"rating" numeric(3, 1),
	"joining_date" date DEFAULT now(),
	"profile_photo" text,
	"password_hash" text NOT NULL,
	"pin_hash" text,
	"status" "member_status" DEFAULT 'PENDING' NOT NULL,
	"is_captain" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "members_member_id_unique" UNIQUE("member_id"),
	CONSTRAINT "members_mobile_unique" UNIQUE("mobile"),
	CONSTRAINT "members_email_unique" UNIQUE("email")
);
--> statement-breakpoint
CREATE TABLE "payment_methods" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" varchar(60) NOT NULL,
	"account_number" varchar(40) NOT NULL,
	"account_name" varchar(120) NOT NULL,
	"instructions" text,
	"warning" text,
	"enabled" boolean DEFAULT true NOT NULL,
	"display_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"member_id" uuid,
	"payment_method_id" uuid,
	"fee_structure_id" uuid,
	"fee_type" varchar(80) NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"transaction_id" varchar(120),
	"screenshot_url" text,
	"note" text,
	"status" "payment_status" DEFAULT 'PENDING' NOT NULL,
	"verified_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "payments_transaction_id_unique" UNIQUE("transaction_id")
);
--> statement-breakpoint
CREATE TABLE "pin_reset_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"member_id" uuid NOT NULL,
	"member_code" varchar(24) NOT NULL,
	"requester_name" varchar(160) NOT NULL,
	"email" varchar(180) NOT NULL,
	"mobile" varchar(30) NOT NULL,
	"status" "application_status" DEFAULT 'PENDING' NOT NULL,
	"email_status" varchar(24) DEFAULT 'NOT_SENT' NOT NULL,
	"email_provider_id" varchar(160),
	"requested_at" timestamp with time zone DEFAULT now() NOT NULL,
	"resolved_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE "posts" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"title" varchar(200) NOT NULL,
	"category" varchar(60) DEFAULT 'Club News' NOT NULL,
	"excerpt" varchar(400) NOT NULL,
	"body" text DEFAULT '' NOT NULL,
	"cover_image" text,
	"status" "post_status" DEFAULT 'DRAFT' NOT NULL,
	"featured_home" boolean DEFAULT false NOT NULL,
	"home_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tournament_applications" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"team_name" varchar(160) NOT NULL,
	"club_name" varchar(160) NOT NULL,
	"manager_name" varchar(160) NOT NULL,
	"mobile" varchar(30) NOT NULL,
	"email" varchar(180) NOT NULL,
	"player_count" integer NOT NULL,
	"category" varchar(80) NOT NULL,
	"address" text NOT NULL,
	"status" "application_status" DEFAULT 'PENDING' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "finance_entries" ADD CONSTRAINT "finance_entries_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "jersey_orders" ADD CONSTRAINT "jersey_orders_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_payment_method_id_payment_methods_id_fk" FOREIGN KEY ("payment_method_id") REFERENCES "public"."payment_methods"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_fee_structure_id_fee_structures_id_fk" FOREIGN KEY ("fee_structure_id") REFERENCES "public"."fee_structures"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "pin_reset_requests" ADD CONSTRAINT "pin_reset_requests_member_id_members_id_fk" FOREIGN KEY ("member_id") REFERENCES "public"."members"("id") ON DELETE cascade ON UPDATE no action;