# Kulanandapur Fantastic FC — Complete Build Specification

Build a football club management platform with a public website, a member portal, and an admin panel. Use this exact stack and structure:

**Stack:** Next.js (App Router) + React + TypeScript + PostgreSQL + Drizzle ORM + Resend (email). Bilingual UI (English/Bangla) throughout via a shared `useI18n()`/`tr(en, bn)` pattern. Session-based auth with signed cookies (no third-party auth provider). Passwords and PINs hashed with scrypt (never stored or shown in plaintext).

---

## 1. Database schema (PostgreSQL via Drizzle)

- **members** — id, memberId (public code like FFC-XXXX), fullName, mobile, email, dateOfBirth, address, emergencyContact, jerseyNumber, position (GOALKEEPER/DEFENDER/MIDFIELDER/FORWARD), matchesPlayed, goals, assists, rating, joiningDate, profilePhoto, passwordHash, pinHash, status (PENDING/ACTIVE/INACTIVE/BLACKLISTED/REJECTED), isCaptain
- **pinResetRequests** — memberId, requesterName, memberCode, status, emailStatus, resolvedAt
- **paymentMethods** — name, details, display order, active flag
- **payments** — memberId, paymentMethodId, feeType, amount, transactionId (unique), screenshotUrl, note, status (PENDING/PAID/REJECTED), verifiedAt
- **tournamentApplications** — teamName, clubName, managerName, mobile, email, playerCount, category, address, status (PENDING/APPROVED/REJECTED)
- **contactMessages** — name, email, mobile, subject, message
- **banners** — title, subtitle, eyebrow, imageUrl, imagePosition, mobileImageUrl, mobileImagePosition, buttonText, buttonLink, isActive, displayOrder
- **lineups** — teamName, matchTitle, formation, isActive, players (jsonb array of {slot, memberId})
- **posts** (news) — title, category, excerpt, body, coverImage, status (DRAFT/PUBLISHED)
- **financeEntries** — title, category (GENERAL/EXPENSE/PLAYER_PAYMENT), income, expense, memberId (for player payments), method, note, createdBy
- **auditLogs** — actor, action, entityType, entityId, details (jsonb)
- **clubSettings** — key/value store (used for admin login credentials under key "adminAuth")
- **matches** — opponentName, matchDatetime, competition, groupName, venue, homeAway, status (UPCOMING/LIVE/COMPLETED/POSTPONED/CANCELLED), homeScore, awayScore

## 2. Public website

Pages: Home, Club/About, Players (squad roster with position filter), Matches/Fixtures, Tournaments, News, Gallery, Contact, Register, Member Login, Admin Login.

- **Header**: logo left, full nav on desktop (Home/Club/Players/Matches/Tournaments/News/Gallery/Contact + language switch + Login + Join the Club). On mobile (viewport ≤900px): logo + hamburger only, opening a slide-in/full-screen menu with the same links plus Member Login and Admin Login, dark overlay, smooth animation.
- **Homepage hero**: eyebrow tagline, headline with an accent-colored second line, subtitle, two CTA buttons ("Explore match centre", "Discover our story"), 4 stat counters (Founded/Active Members/Trophies/Win Rate), a "NEXT MATCH" ribbon overlay showing the soonest upcoming match with a **live countdown timer** (days:hours:minutes:seconds, updates every second, hides once the match starts). Hero background image supports **separate desktop and mobile images with admin-configurable focal-point positioning** (Center/Top/Bottom/Left/Right/Custom, stored per-device in the banners table, applied via CSS custom properties).
- Below the hero: upcoming fixtures strip, intro/story section, featured squad section (4 players, clickable → profile modal), starting-XI pitch diagram (11 positions, populated from the real published lineup), club values/history, latest news grid (from real published posts), join-the-club CTA.
- **Players page**: filterable by position, real squad pulled from active members who have a jersey number assigned. Clicking a player opens a modal with photo, position, captain badge, and real stats (matches/goals/assists/rating).
- **News page**: real published posts with cover photo, category, excerpt; clicking opens a full article modal.
- **Contact form**: saves to DB, sends an auto-reply email to the sender and a notification email to the admin.
- **Tournament application form**: saves to DB, sends confirmation email to applicant + notification to admin.
- **Registration**: creates a PENDING member (requires admin approval before login works).

## 3. Member portal (`/member/...`, behind member session cookie)

Bottom/side nav: Dashboard/Home, Portal menu, Pay, Team, Profile.

- **Dashboard**: welcome card, next match card, quick actions, club overview stats.
- **Our Team**: real published starting XI pitch + full squad list (name, position, jersey), fetched live — not static.
- **Members directory**: searchable list of active squad members.
- **Payments**: submit a fee payment (method, transaction ID, screenshot upload) tied to the logged-in member's own session (never a client-supplied member ID); view own payment history and status.
- **Matches/Fixtures**: view upcoming and past matches.
- **Club Finance / Club Fund**: read-only transparency view — verified income/expense totals, current balance, pending member dues, and a statement table, all computed from real payments + finance ledger data (no fake numbers).
- **Club News**: real published posts.
- **Notifications**: real-time feed built from the member's own account events (e.g., payment verified) — no fake notifications.
- **Documents**: downloadable club documents.
- **Settings**: change password, request PIN reset (never displays the current PIN or its hash — only allows requesting a fresh one, which is emailed).

## 4. Admin panel (`/admin/...`, behind signed admin session cookie — every `/api/admin/*` route must verify this session server-side, not just protect the page route)

Sidebar sections: People & Access (Members, Players, Member Approvals, Jersey Orders, Field & Lineup, PIN Resets, Tournament Apps, Notifications, Audit Log), Finance (Payments, Verification, Financial Overview, Club Fund, Expenses, Payment Methods), Sports (Matches, Fixtures, Tournaments), Content & System (News, Gallery, Announcements, Banners, Logos, Documents, Admin Users, Settings).

- **Dashboard**: live counts (total/active/pending members, pending payments, club fund balance, monthly collection/expense, upcoming matches) — all computed from real data, never hardcoded numbers.
- **Header notification bell + sidebar badge counts**: built live from real pending members / pending payments / pending tournament applications — not fake demo entries, and the count disappears once nothing is pending.
- **Member Approvals**: approve/reject pending registrations.
- **Player Management ("Players")**: assign a jersey number + position to an existing **active member** to add them to the squad (players are members, not a separate fake list); edit jersey/position/captain/stats; "remove from squad" clears their jersey/position without deleting their account (deleting the actual account is a separate, more destructive action).
- **Field & Lineup**: build the starting XI by picking real active squad members into 11 fixed positions (GK/LB/LCB/RCB/RB/LCM/CM/RCM/LW/ST/RW); "Save lineup" persists it to the database and immediately updates what the public site and member portal display.
- **PIN Resets**: table of requests (member, member ID, requested date, status, email status) with Approve/Reject/Resend actions. Approving generates a new random 6-digit PIN, stores only its hash, and emails the plaintext PIN once to the member's registered address via Resend — the PIN itself is never stored in readable form and never shown to admin after the fact (admin can only trigger another reset, not view an existing PIN).
- **Tournament Applications**: real submitted applications with Approve/Reject, each action emails the applicant automatically.
- **Audit Log**: real, append-only log of admin actions (who did what, when), exportable as JSON.
- **Payments/Verification**: approve or reject submitted member payments.
- **Financial Overview / Club Fund / Expenses**: add verified income/expense entries; "Pay a player" sends club funds to a real squad member and logs it; every number shown (verified income, verified expense, current balance, pending dues) is computed live from the database.
- **News Management**: create/edit/delete posts with a cover-photo upload (drag-and-drop or file picker, stored as the post's image), Draft/Published toggle — publishing makes it appear immediately on the public site and member portal.
- **Banners**: manage homepage hero banner(s), including separate desktop/mobile images and the focal-point position dropdown described above.
- **Admin Login & Security**: admin credentials (email + PIN) stored hashed in `clubSettings`; changing them requires the current PIN.

## 5. Security requirements (non-negotiable)

- Every `/api/admin/*` route must call a `requireAdminSession(request)` check at the top and return 401 if it fails — page-level route protection (middleware/proxy) is not sufficient by itself.
- Passwords and PINs are hashed with scrypt (salt:hash format) and verified with timing-safe comparison — never store, log, or display them in plaintext anywhere, including to admins.
- Member-facing write APIs (e.g. submitting a payment) must identify the member from their own session cookie, never trust a client-supplied member ID in the request body.
- No fake/demo/placeholder data anywhere in the shipped product — every list, count, badge, and stat must come from a real database query. If there's no data yet, show an empty state, not a fabricated example.

## 6. Email (via Resend)

Centralize sending in one helper (`to`, `subject`, `html`) that reads `RESEND_API_KEY` and `ADMIN_EMAIL_FROM` from environment variables, and no-ops gracefully (never crashes the request) if the key isn't configured. Trigger emails for: contact form (auto-reply + admin notify), tournament application (confirmation + admin notify), PIN reset (the new PIN), tournament approval/rejection.

## 7. Responsive design

Support 320–430px mobile, 768px tablet, 1024–1920px desktop with no horizontal overflow, no cut-off text/buttons, and a genuinely different (not just shrunk) mobile navigation and hero layout as described above. Admin panel must also be usable on mobile (collapsible sidebar via hamburger, scrollable tables).

## 8. Deployment

Include a `.gitignore` (excluding `node_modules`, `.env`, `.next`), a `.env.example` documenting required variables (`DATABASE_URL`, `RESEND_API_KEY`, `ADMIN_EMAIL_FROM`), a `netlify.toml` for Netlify (Next.js runtime plugin), and standard Vercel compatibility. Run `npx drizzle-kit push` against the target `DATABASE_URL` to create/update tables after deploying.
