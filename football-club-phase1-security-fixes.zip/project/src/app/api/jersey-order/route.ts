import { db } from "@/db";
import { auditLogs, jerseyOrders, members } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { requireAdminSession } from "@/lib/admin-session";
import { MEMBER_SESSION_COOKIE, verifyMemberSessionToken } from "@/lib/member-session";

const UNIT_PRICE = 850;
const SIZES = ["XS", "S", "M", "L", "XL", "XXL", "XXXL", "Custom"];
const STATUSES = ["PENDING", "APPROVED", "PAID", "PROCESSING", "READY", "DELIVERED", "CANCELLED", "REJECTED"];

function memberSessionFrom(request: Request) {
  const cookieHeader = request.headers.get("cookie") || "";
  const token = cookieHeader.split(";").map(p => p.trim()).find(p => p.startsWith(`${MEMBER_SESSION_COOKIE}=`))?.split("=")[1];
  return verifyMemberSessionToken(token);
}

// GET: admin sees every order; a member sees only their own (identified by session, never by a client-supplied id).
export async function GET(request: Request) {
  const admin = requireAdminSession(request);
  const memberSession = admin ? null : memberSessionFrom(request);
  if (!admin && !memberSession) return NextResponse.json({ message: "Sign-in required." }, { status: 401 });

  try {
    const rows = await db.select({
      id: jerseyOrders.id,
      memberId: jerseyOrders.memberId,
      size: jerseyOrders.size,
      jerseyNumber: jerseyOrders.jerseyNumber,
      printName: jerseyOrders.printName,
      quantity: jerseyOrders.quantity,
      unitPrice: jerseyOrders.unitPrice,
      status: jerseyOrders.status,
      createdAt: jerseyOrders.createdAt,
      memberName: members.fullName,
      memberCode: members.memberId,
    }).from(jerseyOrders)
      .leftJoin(members, eq(jerseyOrders.memberId, members.id))
      .where(admin ? undefined : eq(jerseyOrders.memberId, memberSession!.memberId))
      .orderBy(desc(jerseyOrders.createdAt));

    return NextResponse.json({ orders: rows }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Jersey load failed", error);
    return NextResponse.json({ orders: [] });
  }
}

// POST: a logged-in active member orders for themselves (member id always comes from the session,
// never from the request body — the client cannot order on behalf of another member). Admin may
// also place a manual order for a specific member selected from the real members table.
export async function POST(request: Request) {
  const admin = requireAdminSession(request);
  const memberSession = admin ? null : memberSessionFrom(request);
  if (!admin && !memberSession) return NextResponse.json({ message: "Sign-in required." }, { status: 401 });

  try {
    const body = (await request.json()) as Record<string, unknown>;
    const size = String(body.size || "").trim();
    const jerseyNumber = Number(body.jerseyNumber) || 0;
    const printName = String(body.printName || "").trim().slice(0, 40).toUpperCase();
    const quantity = Math.max(1, Math.min(10, Number(body.quantity) || 1));
    if (!SIZES.includes(size) || !printName || jerseyNumber < 1 || jerseyNumber > 99) {
      return NextResponse.json({ message: "Select a valid size, jersey number and print name." }, { status: 400 });
    }

    let memberDbId: string;
    if (admin) {
      memberDbId = typeof body.memberDatabaseId === "string" ? body.memberDatabaseId : "";
      if (!memberDbId) return NextResponse.json({ message: "Select a member for this order." }, { status: 400 });
      const [target] = await db.select({ id: members.id }).from(members).where(eq(members.id, memberDbId)).limit(1);
      if (!target) return NextResponse.json({ message: "Member not found." }, { status: 404 });
    } else {
      const [self] = await db.select({ id: members.id, status: members.status }).from(members).where(eq(members.id, memberSession!.memberId)).limit(1);
      if (!self || self.status !== "ACTIVE") return NextResponse.json({ message: "Only active members can order a jersey." }, { status: 403 });
      memberDbId = self.id;
    }

    const [created] = await db.insert(jerseyOrders).values({
      memberId: memberDbId,
      size,
      jerseyNumber,
      printName,
      quantity,
      unitPrice: UNIT_PRICE.toFixed(2),
      status: "PENDING",
    }).returning();

    if (admin) {
      await db.insert(auditLogs).values({ actor: admin.email, action: "Manual jersey order created", entityType: "JERSEY_ORDER", entityId: created.id, details: { memberDbId, size, jerseyNumber, printName, quantity } });
    }

    return NextResponse.json({ message: "Jersey order submitted for admin review.", order: created }, { status: 201 });
  } catch (error) {
    console.error("Jersey order failed", error);
    return NextResponse.json({ message: "Unable to submit jersey order." }, { status: 500 });
  }
}

// PATCH: admin only — update status (or, for a manual order, its details).
export async function PATCH(request: Request) {
  const admin = requireAdminSession(request);
  if (!admin) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const id = typeof body.id === "string" ? body.id : "";
    if (!id) return NextResponse.json({ message: "Invalid action." }, { status: 400 });

    const patch: Partial<typeof jerseyOrders.$inferInsert> = { updatedAt: new Date() };
    if (typeof body.status === "string") {
      if (!STATUSES.includes(body.status)) return NextResponse.json({ message: "Invalid status." }, { status: 400 });
      patch.status = body.status as typeof jerseyOrders.$inferInsert.status;
    }
    if (typeof body.size === "string" && SIZES.includes(body.size)) patch.size = body.size;
    if (body.jerseyNumber !== undefined) {
      const num = Number(body.jerseyNumber);
      if (num >= 1 && num <= 99) patch.jerseyNumber = num;
    }
    if (typeof body.printName === "string" && body.printName.trim()) patch.printName = body.printName.trim().slice(0, 40).toUpperCase();
    if (body.quantity !== undefined) {
      const qty = Number(body.quantity);
      if (qty >= 1 && qty <= 10) patch.quantity = qty;
    }
    if (body.unitPrice !== undefined) {
      const price = Number(body.unitPrice);
      if (Number.isFinite(price) && price >= 0) patch.unitPrice = price.toFixed(2);
    }

    const [updated] = await db.update(jerseyOrders).set(patch).where(eq(jerseyOrders.id, id)).returning();
    if (!updated) return NextResponse.json({ message: "Order not found." }, { status: 404 });

    await db.insert(auditLogs).values({ actor: admin.email, action: "Jersey order updated", entityType: "JERSEY_ORDER", entityId: id, details: patch });
    return NextResponse.json({ message: "Order updated.", order: updated });
  } catch (error) {
    console.error("Jersey update failed", error);
    return NextResponse.json({ message: "Unable to update order." }, { status: 500 });
  }
}

// DELETE: admin only.
export async function DELETE(request: Request) {
  const admin = requireAdminSession(request);
  if (!admin) return NextResponse.json({ message: "Admin sign-in required." }, { status: 401 });
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id") || "";
    if (!id) return NextResponse.json({ message: "Missing order id." }, { status: 400 });
    await db.delete(jerseyOrders).where(eq(jerseyOrders.id, id));
    await db.insert(auditLogs).values({ actor: admin.email, action: "Jersey order deleted", entityType: "JERSEY_ORDER", entityId: id, details: {} });
    return NextResponse.json({ message: "Order deleted." });
  } catch (error) {
    console.error("Jersey delete failed", error);
    return NextResponse.json({ message: "Unable to delete order." }, { status: 500 });
  }
}
